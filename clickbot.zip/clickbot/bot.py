from telethon import TelegramClient, sync, events, errors, connection
from telethon.tl.functions.messages import *
from telethon.tl.types import *
from telethon.tl.functions.messages import *
from telethon.tl.functions.account import *
from telethon.tl.functions.channels import UpdateUsernameRequest as chusername
from telethon.tl.functions.channels import *
from telethon.errors.rpcerrorlist import *
from telethon.tl.types import *
from telethon.tl.functions.contacts import *
from telethon.errors import *
from telethon.tl.functions import *
import traceback
from json.decoder import JSONDecodeError
from sqlite3 import OperationalError
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
import pytz, json, re, sys, os, requests, time, random, colorama, threading, itertools, stat
import asyncio
import getpass
import logging
import datetime
a=time.localtime()
hr=a.tm_hour
if hr < 4 :
    ucap = "Selamat Malam!"
else:
    if hr < 11:
        ucap = "Selamat Pagi,, Selamat Beraktifitas!"
    else:
        if hr < 16 :
            ucap = "Selamat Siang!"
        else:
            if hr < 19 :
                ucap = "Selamat Sore!"
            else:
                ucap = "Selamat Malam Semuanya!"
mn=a.tm_min
sc=a.tm_sec
dy=a.tm_mday
xxtime=('{}:{}:{}'.format(hr,mn,sc))

try:
   from func_timeout import FunctionTimedOut, func_timeout
except:
   os.system("pip install func_timeout")
res  = "\033[1;0m"
hi = "\033[0;30m"
hitam  = "\033[1;30m"
merah1 = "\033[0;31m" 
merah = "\033[1;31m"
hijau2 = "\033[0;32m"
hijau = "\033[1;32m"
emas = "\033[0;33m"
kuning = "\033[1;33m"
bir = "\033[0;34m"  
biru = "\033[1;34m"
purp = "\033[0;35m"
purple  = "\033[1;35m"
cyan1 = "\033[0;36m"
cyan = "\033[1;36m"
abu2 = "\033[0;37m"
putih = "\033[1;37m"
kur1 = "\033[1;31m"+"["
kur2 = "\033[1;31m"+"]"
kur3 = "\033[1;31m"+"["+"\033[1;32m"+"+"+"\033[1;31m"+"]"
ffr = "🔥"
inn = "👉"
plus = "\033[1;30m"+"["+"\033[1;32m"+"+"+"\033[1;30m"+"]"
tase = "\033[1;30m"+"["+"\033[1;33m"+"!"+"\033[1;30m"+"]"
tata = "\033[1;30m"+"["+"\033[1;33m"+"?"+"\033[1;30m"+"]"
tasi = "\033[1;30m"+"["+"\033[1;31m"+"x"+"\033[1;30m"+"]"
taku = "\033[1;30m"+"["+"\033[1;33m"+"-"+"\033[1;30m"+"]"
mes = ["\033[0;31m" ,"\033[1;31m","\033[0;32m","\033[1;32m","\033[0;33m","\033[1;33m","\033[0;34m","\033[1;34m","\033[0;35m","\033[1;35m","\033[0;36m","\033[1;36m","\033[0;37m","\033[1;37m"]
pamerah = hitam+"]"+merah+">>>"
pahijau = hitam+"]"+hijau+">>>"
pakuning = hitam+"]"+kuning+">>>"
warna = random.choice(mes)
xtime = time.asctime(time.localtime(time.time()))
os.system('cls' if os.name=='nt' else 'clear')
os.system('clear')
def tunggu(x):    
    sys.stdout.write("\r")    
    sys.stdout.write("                                                               ")    
    for remaining in range(x, 0, -1):
        sys.stdout.write("\r")
        sys.stdout.write("\x1b[0;37m[\x1b[0;33m|\x1b[0;37m]\x1b[1;32m wait \x1b[1;0m{:2d} \x1b[1;32mseconds remaining".format(remaining))
        sys.stdout.flush()
        sleep(0.125)
        sys.stdout.write("\r")
        sys.stdout.write("\x1b[0;37m[\x1b[0;33m/\x1b[0;37m]\x1b[1;33m wait \x1b[1;0m{:2d} \x1b[1;32mseconds remaining".format(remaining))
        sys.stdout.flush()
        sleep(0.125)
        sys.stdout.write("\r")
        sys.stdout.write("\x1b[0;37m[\x1b[0;33m-\x1b[0;37m]\x1b[1;32m wait \x1b[1;0m{:2d} \x1b[1;32mseconds remaining".format(remaining))
        sys.stdout.flush()
        sleep(0.125)
        sys.stdout.write("\r")
        sys.stdout.write("\x1b[0;37m[\x1b[0;33m|\x1b[0;37m]\x1b[1;33m wait \x1b[1;0m{:2d} \x1b[1;32mseconds remaining".format(remaining))
        sys.stdout.flush()
        sleep(0.125)
        sys.stdout.write("\r")
        sys.stdout.write("\x1b[0;37m[\x1b[0;33m|\x1b[0;37m]\x1b[1;32m wait \x1b[1;0m{:2d} \x1b[1;32mseconds remaining".format(remaining))
        sys.stdout.flush()
        sleep(0.125)
        sys.stdout.write("\r")
        sys.stdout.write("\x1b[0;37m[\x1b[0;33m/\x1b[0;37m]\x1b[1;33m wait \x1b[1;0m{:2d} \x1b[1;32mseconds remaining".format(remaining))
        sys.stdout.flush()
        sleep(0.125)
        sys.stdout.write("\r")
        sys.stdout.write("\x1b[0;37m[\x1b[0;33m-\x1b[0;37m]\x1b[1;32m wait \x1b[1;0m{:2d} \x1b[1;32mseconds remaining".format(remaining))
        sys.stdout.flush()
        sleep(0.125)
        sys.stdout.write("\r")
        sys.stdout.write("\x1b[0;37m[\x1b[0;33m|\x1b[0;37m]\x1b[1;33m wait \x1b[1;0m{:2d} \x1b[1;32mseconds remaining".format(remaining))
        sys.stdout.flush()
        sleep(0.125)
    sys.stdout.write("\r                                                 \r")
    sys.stdout.write(f"\r\x1b[0;37m[\x1b[1;32m+\x1b[0;37m] \x1b[1;32mGetting Reward")


def wd():    
    print(f'{hijau}=========={kur1}{biru} WITHDRAW BALANCE {kur2}{hijau}==========\n')    
    for i in range(5):    
        sys.stdout.write('\r')    
        sys.stdout.write('                                                               ')    
        sys.stdout.write('\r')    
        sys.stdout.write(f'{abu2}[{kuning}!{abu2}] {kuning}Trying to withdraw')    
        sys.stdout.flush()    
        client.send_message(entity=channel_entity, message='💰 Balance')    
        sleep(2)    
        posts = client(GetHistoryRequest(peer=channel_entity, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))    
        message = posts.messages[0].message    
        all = message    
        bal = all.strip('Available balance: ')    
        sleep(2)    
        client.send_message(entity=channel_entity, message='/withdraw')    
        sleep(2)    
        posts = client(GetHistoryRequest(peer=channel_entity, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))    
        if posts.messages[0].message.find('Your balance is too small to') != -1:    
            sys.stdout.write(f"\r{abu2}[{kuning}-{abu2}] {kuning}{all}\n")    
            print(f'\n\n\r{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')
            sys.exit()
        else:    
            client.send_message(entity=channel_entity, message=dompet)    
            sleep(2)    
            client.send_message(entity=channel_entity, message=bal)    
            sleep(2)    
            client.send_message(entity=channel_entity, message='/Confirm')    
            sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Succes withdraw {bal} {channel_username}\n")    
            print(f'\n\n\r{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')
            sys.exit()
                
def visit():    
    print(f'{hijau}=========={kur1}{biru} VISITING BOT {kur2}{hijau}==========\n')    
    for i in range(150):    
        sys.stdout.write('\r')    
        sys.stdout.write('                                                               ')    
        sys.stdout.write('\r')    
        sys.stdout.write(f'{abu2}[{kuning}!{abu2}] {kuning}Trying to get an url')    
        sys.stdout.flush()    
        client.send_message(entity=channel_entity,message="🖥 Visit sites")    
        sleep(2)    
        posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))    
        if posts.messages[0].message.find('Sorry, there are no new ads available') != -1:    
            sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Sorry, there are no new ads available. \n\n')    
            if fitur_auto_wd == "on":wd()    
            if fitur_auto_wd == "off":exit()    
            else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
            break    
                
        else:    
            try:    
                url = posts.messages[0].reply_markup.rows[0].buttons[0].url    
                sys.stdout.write('\r')    
                sys.stdout.write(f'{abu2}[{kuning}!{abu2}] {kuning}Visit ' + url)    
                sys.stdout.flush()    
                id = posts.messages[0].id    
                r = c.get(url, headers=ua, timeout=15, allow_redirects=True)    
                soup = BeautifulSoup(r.content, 'html.parser')    
                if soup.find("div",class_="g-recaptcha") is None and soup.find('div', id="headbar") is None:    
                    sleep(2)    
                    posts = client(GetHistoryRequest(peer=channel_entity, limit=1, offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))    
                    message = posts.messages[0].message    
                    if posts.messages[0].message.find('Please stay on') != -1 or posts.messages[0].message.find('You must stay') != -1:    
                        sec = re.findall('([\d.]*\d+)', message)    
                        tunggu(int(sec[0]))    
                        sleep(2)    
                        posts = client(GetHistoryRequest(peer=channel_entity, limit=2, offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))    
                        messageres = posts.messages[1].message    
                        sleep(2)    
                        sys.stdout.write(f'\r{abu2}[{hijau}+{abu2}] {hijau}' + messageres + '\n')    
                    else:    
                    	pass    
                         
                elif soup.find('div', id='headbar') is not None:    
                    for dat in soup.find_all("div",class_='container-fluid'):    
                        code = dat.get('data-code')    
                        timer = dat.get('data-timer')    
                        tokena = dat.get('data-token')    
                        tunggu(int(timer))    
                        r = c.post('https://dogeclick.com/reward', data={'code':code,  'token':tokena}, headers=ua, timeout=15, allow_redirects=True)    
                        js = json.loads(r.text)    
                        sys.stdout.write(f'\r{abu2}[{hijau}+{abu2}] {hijau}You earned ' + js['reward'] + f" {currency} for visiting a site!\n")    
                else:    
                    sys.stdout.write('\r')    
                    sys.stdout.write('                                                                 ')    
                    sys.stdout.write('\r')    
                    sys.stdout.write(f'{abu2}[{merah}x{abu2}] {merah}Captcha Detected')    
                    sys.stdout.flush()    
                    sleep(2)    
                    client(GetBotCallbackAnswerRequest(channel_username, id, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))    
                    sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip Captcha...!       \n')    
                    sleep(2)  
            except:    
                sleep(2)    
                posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))    
                message = posts.messages[0].message    
                if posts.messages[0].message.find("You must stay") != -1 or posts.messages[0].message.find("Please stay on") != -1:    
                    sec = re.findall('([\d.]*\d+)', message)    
                    tunggu(int(sec[0]))    
                    sleep(2)    
                    posts = client(GetHistoryRequest(peer=channel_entity,limit=2,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))    
                    messageres = posts.messages[1].message    
                    sleep(2)    
                    sys.stdout.write(f'\r{abu2}[{hijau}+{abu2}] {hijau}' + messageres + '\n')    
                else:    
                	pass
def leave():
    print(f'{hijau}=========={kur1}{biru} Leave Channel/Group {kur2}{hijau}==========\n')    
    b = client.get_dialogs()
    k = b.total
    nl = open('noleave.txt', 'r').read().splitlines()
    print(f"{abu2}[{hijau}+{abu2}]{kuning} Total list No leave : {putih}",len(nl))
    print(f"{abu2}[{hijau}+{abu2}]{merah} Total : {putih}{k}")
    for pipis in b:
        k = k - 1
        if pipis.is_channel:
            us = pipis.entity.username
            al = pipis.entity
            uss = open('noleave.txt', 'r').read()
            nm = pipis.title   
            bb = pipis.name
            adm = pipis.entity.admin_rights
            crt = pipis.entity.creator
            try:
                if uss.find(str(al)) !=-1 or uss.find(str(us)) !=-1:
                    print(f"\r{abu2}[{kuning}#{abu2}] {kuning}No Leave >>>{biru} {nm}")
                    sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Available {abu2}[{kuning}"+str(k)+f"{abu2}] ") 
                    continue
                else:
                    try:
                        if adm is None and crt is False:
                            try:
                                client(LeaveChannelRequest(al))
                                print(f"\r{abu2}[{hijau}{hijau}+{abu2}] {merah}Leave >>>{biru} {nm}")
                                sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Available {abu2}[{kuning}"+str(k)+f"{abu2}] ")
                            except:
                                client.delete_dialog(us)
                                print(f"\r{abu2}[{hijau}{hijau}+{abu2}] {merah}Leave >>>{biru} {nm}")
                                sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Available {abu2}[{kuning}"+str(k)+f"{abu2}] ")
                        else:
                            print(f"\r{abu2}[{hijau}#{abu2}] {hijau}No Leave Your Admin >>>{biru} {nm}")
                    except:
                        print(f"\r{abu2}[{hijau}+{abu2}] {hijau}Leave Channel/Group Private{biru} {nm}")
            except:
                pass
    c = client.get_dialogs(777)
    t = c.total
    print(f"\r{abu2}[{hijau}+{abu2}] {hijau}>>> Available {abu2}[{kuning}{t}{abu2}] ")
    print (f'\r{abu2}[{merah}x{abu2}] {merah}No More Channels/Groups ......!!!\n')
    if fitur_msg == "on":mesg()
    if fitur_msg == "off":
        if fitur_join == "on":join()
        if fitur_join == "off":
            if fitur_visit == "on":visit()
            if fitur_visit == "off":wd()
            else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file {kuning}{set}, {merah}please check again {kuning}{set} !')
        else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file {kuning}{set}, {merah}please check again {kuning}{set} !')
    else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file {kuning}{set}, {merah}please check again {kuning}{set} !')
           
def join():    
    print(f'{hijau}=========={kur1}{biru} JOINING BOT {kur2}{hijau}==========\n')    
    for i in range(10):    
        sys.stdout.write('\r')    
        sys.stdout.write('                                                               ')    
        sys.stdout.write('\r')    
        sys.stdout.write(f'{abu2}[{kuning}!{abu2}] {kuning}Trying to join channel')    
        sys.stdout.flush()    
        client.send_message(entity=channel_entity, message='📣 Join chats')    
        sleep(2)    
        posts = client(GetHistoryRequest(peer=channel_entity, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))    
        messag = posts.messages[0].message    
        msg_id = posts.messages[0].id    
        if posts.messages[0].message.find('Sorry, there are no new ads available') != -1 or posts.messages[0].message.find('You are sending too many messages') != -1:
            sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Sorry, there are no new ads available. \n\n')    
            if fitur_visit == "on":visit()    
            if fitur_visit == "off":    
                if fitur_auto_wd == "on":wd()    
                if fitur_auto_wd == "off":exit()    
                else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
            else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
            break               
        else:
            try:
                url = posts.messages[0].reply_markup.rows[0].buttons[0].url
                if url.find('https://t.me/') > 0:
                    bot = url.replace('https://t.me/', '@')
                else:
                    r = c.get(url, headers=ua, timeout=15, allow_redirects=True)
                    soup = BeautifulSoup(r.content, 'html.parser')
                    dat = soup.find('title')
                    bt = dat.text.strip()
                    bot = bt.replace('Telegram: Contact', '')
                channel_name = client.get_entity(bot)
                client(JoinChannelRequest(channel_name))
                sleep(2)    
                client(GetBotCallbackAnswerRequest(channel_entity, msg_id, data=(posts.messages[0].reply_markup.rows[0].buttons[1].data)))    
                sys.stdout.write('\r')    
                sys.stdout.write('                                                                 ')    
                sys.stdout.write('\r')    
                sys.stdout.write(f"{abu2}[{kuning}-{abu2}] {kuning}Joining bot {bot}")    
                sys.stdout.flush()    
                sleep(2)    
                posts_ = client(GetHistoryRequest(peer=channel_entity, limit=2, offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))    
                id = posts_.messages[1].id    
                msg = posts_.messages[1].message    
                musang = re.findall('([\d.]*\d+)', msg)    
                if posts_.messages[0].message.find('cannot find you') != -1:    
                    client(GetBotCallbackAnswerRequest(channel_entity, id, data=(posts_.messages[1].reply_markup.rows[1].buttons[1].data)))    
                    sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task...!                                                            ')    
                    continue    
                    sleep(2)            
                else:    
                    sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}You earned after {musang[0]} hours for joining bot!\n")    
                    sleep(2)
            except Exception:
                client(GetBotCallbackAnswerRequest(channel_entity, msg_id, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))
            except UsernameNotOccupiedError:    
                client(GetBotCallbackAnswerRequest(channel_entity, msg_id, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task...! Invalid Username Channel                                               ')
                continue
            except ChannelInvalidError:
                client(GetBotCallbackAnswerRequest(channel_entity, msg_id, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task...! Channel not Found                                                   ')    
                continue    
                sleep(2)
            except ValueError:
                client(GetBotCallbackAnswerRequest(channel_entity, msg_id, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task...! Value Error                                                 ')    
                continue    
                sleep(2)
            except UsernameInvalidError:
                client(GetBotCallbackAnswerRequest(channel_entity, msg_id, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task...! Channel Fake                                                   ')    
                continue    
                sleep(2)
            except ChannelsTooMuchError:
                sys.stdout.write(f"\r{abu2}[{kuning}!{abu2}] {kuning}Hi {kur1}{biru} {myself.first_name} {kur2} {kuning}Terlalu Banyak Channel/Grup Yang di join{putih}\n\n")
                sleep(2)
                sys.stdout.write(f"\r{abu2}[{kuning}!{abu2}] {kuning}Switch to Leave\n\n")
                if full == "on":leave()
                if full == "off":
                    if fitur_visit == "on":visit()
                    if fitur_visit == "off":wd()
                    else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file {kuning}{set}, {merah}please check again {kuning}{set} !')
                else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file {kuning}{set}, {merah}please check again {kuning}{set} !')
            except errors.FloodWaitError as e:    
                try:    
                    sys.stdout.write(f"\r{abu2}[{kuning}!{abu2}] {kuning}Hi {biru}{myself.first_name} {kuning}you must sleep {e.seconds} seconds For Join Again\n\n")    
                    if fitur_visit == "on":visit()    
                    if fitur_visit == "off":    
                        if fitur_auto_wd == "on":wd()    
                        if fitur_auto_wd == "off":exit()    
                        else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
                    else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')
                finally:    
                    e = None    
                    del e       
            except Exception:    
                client(GetBotCallbackAnswerRequest(channel_entity, msg_id, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))    
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task...!                                                            ')
    else:
        sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Sorry, there are no new ads available. \n\n')
        if fitur_visit == "on":visit()
        if fitur_visit == "off":
            if fitur_auto_wd == "on":wd()
            if fitur_auto_wd == "off":exit()
            else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')
        else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')
   
def mesg():    
    print(f'{hijau}=========={kur1}{biru} MESSAGING BOT {kur2}{hijau}==========\n')    
    for i in range(5):    
        sys.stdout.write('\r')    
        sys.stdout.write('                                                               ')    
        sys.stdout.write('\r')    
        sys.stdout.write(f'{abu2}[{kuning}!{abu2}] {kuning}Trying to messaging channel')    
        sys.stdout.flush()    
        client.send_message(entity=channel_entity, message='🤖 Message bots')    
        sleep(2)    
        posts = client(GetHistoryRequest(peer=channel_entity, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))    
        id_ = posts.messages[0].id
        if posts.messages[0].message.find('Sorry, there are no new ads available') != -1:    
            sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Sorry, there are no new ads available. \n\n')    
            if fitur_join == "on":join()    
            if fitur_join == "off":    
                if fitur_visit == "on":visit()    
                if fitur_visit == "off":    
                    if fitur_auto_wd == "on":wd()    
                    if fitur_auto_wd == "off":exit()    
                    else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
                else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
            else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
                                      
        else:    
            try:    
                url = posts.messages[0].reply_markup.rows[0].buttons[0].url
                id_ = posts.messages[0].id
                r = c.get(url, headers=ua, timeout=15, allow_redirects=True)    
                soup = BeautifulSoup(r.content, 'html.parser')    
                dat = soup.find('div', class_='tgme_page_extra')    
                bot = dat.text.strip()
                channel_name = client.get_entity(bot)    
                sys.stdout.write('\r')    
                sys.stdout.write('                                                                ')    
                sys.stdout.write('\r')    
                sys.stdout.write(f"{abu2}[{kuning}-{abu2}] {kuning}Messaging bot {bot}")    
                sys.stdout.flush()    
                sleep(3)
                client.send_message(entity=channel_name, message='/start')    
                sleep(3)
                if posts__.messages[0].message.find("/start") != -1:
                    client(GetBotCallbackAnswerRequest(channel_entity, id_, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))
                    sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task !! Not respon from bot {bot} ...!                                                            \n')
                else:
                    posts_ = client(GetHistoryRequest(peer=channel_name, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))    
                    msg_id = posts_.messages[0].id
                    message = posts_.messages[0].message
                    sleep(2)
                    client.forward_messages(channel_entity, msg_id, channel_name)    
                    sleep(3)    
                    posts__ = client(GetHistoryRequest(peer=channel_entity, limit=3, offset_date=None, offset_id=0, max_id=0, min_id=0, add_offset=0, hash=0))    
                    msg = posts__.messages[1].message    
                    msgc = posts__.messages[0].message
                    id = posts__.messages[2].id
                    id__= posts__.messages[1].id
                    if posts__.messages[0].message.find('not a valid') != -1 or posts__.messages[0].message.find("That is not a recognized command") != -1:
                        client(GetBotCallbackAnswerRequest(channel_entity, id, data=(posts__.messages[2].reply_markup.rows[1].buttons[1].data)))
                        sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task...!                                                            \n')    
                        sleep(2)       
                    else:    
                        sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}{msg}\n")    
                        sleep(2)
            except YouBlockedUserError:
                print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Unblok {bot}")    
                client(UnblockRequest(channel_name))    
                print(f"\r{abu2}[{hijau}+{abu2}] {hijau}Done.....!!!")    
                continue
            except BotInvalidError:
                client(GetBotCallbackAnswerRequest(channel_entity, id_, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task bot error...!                                                            \n')
                continue
            except UsernameInvalidError:
                client(GetBotCallbackAnswerRequest(channel_entity, id_, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))    
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task bot not found...!                                                            \n')    
                sleep(2)
                continue
            except UsernameNotOccupiedError:    
                client(GetBotCallbackAnswerRequest(channel_entity, id_, data=(posts.messages[0].reply_markup.rows[1].buttons[1].data)))    
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Skip task bot not found...!                                                            \n')    
                sleep(2)
                continue
            except Exception:
                sys.stdout.write(f'\r{abu2}[{merah}x{abu2}] {merah}Sorry, there are no new ads available. \n\n')
                if fitur_join == "on":join()
                if fitur_join == "off":
                    if fitur_visit == "on":visit()
                    if fitur_visit == "off":
                        if fitur_auto_wd == "on":wd()
                        if fitur_auto_wd == "off":exit()
                        else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')
                    else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')
                else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')                   
    
def start():
    print(f'{hijau}=========={kur1}{putih} {xtime} {kur2}{hijau}==========')
    d=client.get_entity("@Dogecoin_click_bot")
    doge="@Dogecoin_click_bot"
    l=client.get_entity("@Litecoin_click_bot")
    ltc="@Litecoin_click_bot"
    bc=client.get_entity("@BCH_clickbot")
    bch="@BCH_clickbot"
    bt=client.get_entity("@BitcoinClick_bot")
    btc="@BitcoinClick_bot"
    z=client.get_entity("@Zcash_click_bot")
    zec="@Zcash_click_bot"
    try:
        sys.stdout.write(f'\r{abu2}[{kuning}!{abu2}] {kuning}Try to Referral Clickbot')
        try:
            client.send_message(entity=d,message="/start "+ref_doge)
            sleep(2)
            posts = client(GetHistoryRequest(peer=d,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {doge} Sucses!!         ')
        except YouBlockedUserError:
            sys.stdout.write(f"\r{abu2}[{kuning}+{abu2}] {kuning}Unblok Bot {doge}")
            client(UnblockRequest(d))
            sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Done.....!!!                    ")
            client.send_message(entity=d,message="/start "+ref_doge)
            sleep(2)
            posts = client(GetHistoryRequest(peer=d,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {doge} Sucses!!          ')
        try:
            client.send_message(entity=l,message="/start "+ref_ltc)
            sleep(2)
            posts = client(GetHistoryRequest(peer=l,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {ltc} Sucses!!          ')
        except YouBlockedUserError:
            sys.stdout.write(f"\r{abu2}[{kuning}+{abu2}] {kuning}Unblok Bot {ltc}")
            client(UnblockRequest(l))
            sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Done.....!!!                    ")
            client.send_message(entity=l,message="/start "+ref_ltc)
            sleep(2)
            posts = client(GetHistoryRequest(peer=l,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {ltc} Sucses!!          ')
        try:
            client.send_message(entity=bc,message="/start "+ref_bch)
            sleep(2)
            posts = client(GetHistoryRequest(peer=bc,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {bch} Sucses!!          ')
        except YouBlockedUserError:
            sys.stdout.write(f"\r{abu2}[{kuning}+{abu2}] {kuning}Unblok Bot {bch}")
            client(UnblockRequest(bc))
            sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Done.....!!!                    ")
            client.send_message(entity=bc,message="/start "+ref_bch)
            sleep(1)
            posts = client(GetHistoryRequest(peer=bc,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {bch} Sucses!!          ')
        try:
            client.send_message(entity=bt,message="/start "+ref_btc)
            sleep(2)
            posts = client(GetHistoryRequest(peer=bt,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
               print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {btc} Sucses!!          ')      
        except YouBlockedUserError:
            sys.stdout.write(f"\r{abu2}[{kuning}+{abu2}] {kuning}Unblok Bot {doge}")
            client(UnblockRequest(bt))
            sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Done.....!!!                    ")
            client.send_message(entity=bt,message="/start "+ref_btc)
            sleep(2)
            posts = client(GetHistoryRequest(peer=bt,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {btc} Sucses!!          ')        
        try:
            client.send_message(entity=z,message="/start "+ref_zec)
            sleep(2)
            posts = client(GetHistoryRequest(peer=z,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {zec} Sucses!!          ')
        except YouBlockedUserError:
            sys.stdout.write(f"\r{abu2}[{kuning}+{abu2}] {kuning}Unblok Bot {zec}")
            client(UnblockRequest(z))
            sys.stdout.write(f"\r{abu2}[{hijau}+{abu2}] {hijau}Done.....!!!                    ")
            client.send_message(entity=z,message="/start "+ref_zec)
            sleep(2)
            posts = client(GetHistoryRequest(peer=z,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
            msg = posts.messages[0].message
            if msg.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Referral {zec} Sucses!!          ')               
        client.send_message(entity=channel_entity,message="/menu")    
        sleep(3)
        posts = client(GetHistoryRequest(peer=channel_entity,limit=1,offset_date=None,offset_id=0,max_id=0,min_id=0,add_offset=0,hash=0))
        msg = posts.messages[0].message
        sleep(5)
        if posts.messages[0].message.find("/menu") != -1:
            print(f'\r{abu2}[{merah}x{abu2}] {merah}{channel_username} To slow respon..!! Try Again Later.. !')
            sleep(2)
            sys.exit()
        else:
            if posts.messages[0].message.find("Welcome") != -1:
                print(f'\r{abu2}[{hijau}+{abu2}]{hijau} Run Bot {channel_username} !!          ')
                sleep(1)
        print (f'{abu2}[{hijau}+{abu2}]{hijau} Run Script!!\n')
        if fitur_msg == "on":mesg()    
        if fitur_msg == "off":    
            if fitur_join == "on":join()    
            if fitur_join == "off":    
                if fitur_visit == "on":visit()    
                if fitur_visit == "off":    
                    if fitur_auto_wd == "on":wd()    
                    if fitur_autowd == "off":exit()    
                    else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
                else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
            else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')    
        else:exit(f'{abu2}[{merah}x{abu2}] {merah}wrong file configuration, please check again configuration file !')
    except YouBlockedUserError:
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Unblok {channel_username}")    
        client(UnblockRequest(channel_entity))    
        print(f"\r{abu2}[{hijau}+{abu2}] {hijau}Done.....!!!")
    
r = requests.Session()
free = r.get("https://pastebin.com/raw/d89DBMDz").text
banner =(f"""{kuning}
	_  _ _  _ _    _    ____ _  _ _    _ _  _ ____ 
	|_/  |  | |    |    |  | |\ | |    | |\ | |___ 
	| \_ |__| |___ |    |__| | \| |___ | | \| |___ 
{hijau}============================================================
{kur1} {biru}By xuZut™ {kur2}
{hijau}© Telegram {merah}: {hijau}@kuli_online_group
{hijau}© Youtube  {merah}: {hijau}KULI ONLine
{hijau}Support By {merah}: {hijau}All Admin Kuli ONLine
{hijau}Thanks For {merah}: {hijau}All Member Kuli ONLine & Airdrop Hunter
{hijau}============================================================
{kur1}{biru} SCRIPT ALL CLICKBOT {merah}|{hijau} {free} {kur2}
{hijau}============================================================""")
print(banner)
c = requests.Session()
namasc = sys.argv[0]
if not os.path.exists('session'):    
    os.makedirs('session')
if not os.path.exists('akun.sh'):    
    open('akun.sh','a+')
if not os.path.exists('list_active.txt'):    
    open('list_active.txt','a+')
if not os.path.exists('list_banned.txt'):    
    open('list_banned.txt', 'a+')
if not os.path.exists('corrupt_session.txt'):    
    open('corrupt_session.txt','a+')
if len(sys.argv) < 2:    
    sys.stdout.write(f'\r\n\n\x1b[1;37m[{hijau}+\x1b[1;37m]{merah}Baca Tutorial Makanya')    
    sleep(3)    
    print(f'\r{kur1}{hijau}+{kur2}{hijau}Contoh : python {namasc} +6190xxxxx doge(currency)')    
    sys.exit()
if len(sys.argv) < 3:    
    sys.stdout.write(f'\r\n\n\x1b[1;37m[{hijau}+\x1b[1;37m]{merah}Baca Tutorial Makanya')    
    sleep(3)    
    print(f'\r{kur1}{hijau}+{kur2}{hijau}Pakai Currency Setelah Nomor Akun')    
    sys.exit()
ua = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win32; x86) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36'}
set = 'configuration.json'
with open(set, 'r') as myfile:
    try:
        data = myfile.read()
        obj = json.loads(data)
        ltcwallet = obj['walletltc']
        dogewallet = obj['walletdoge']
        zecwallet = obj['walletzec']
        bchwallet = obj['walletbch']
        btcwallet = obj['walletbtc']
        ref_btc = obj["ref_btc"]
        ref_ltc = obj["ref_ltc"]
        ref_bch = obj["ref_bch"]
        ref_zec = obj["ref_zec"]
        ref_doge = obj["ref_doge"]
        fitur_join = obj["fitur"]["join"].lower()
        fitur_auto_wd = obj["fitur"]["auto_wd"].lower()
        fitur_msg = obj["fitur"]["msg"].lower()
        fitur_visit = obj["fitur"]["visit"].lower()
        full = obj["fitur"]["leave_if_channel_full"].lower()
    except json.decoder.JSONDecodeError:
        print(f'\r{abu2}[{merah}x{abu2}] {merah}Warning Error, Please Check {kuning}{set} {merah}Again')
        print(f"{hijau}============================================================\n")
        sys.exit()
try:    
    api_id = 974754
    api_hash = '6295657bbae725bfe8dfcca5d9e323e6'
    phone_number = sys.argv[1]    
    pilihan = sys.argv[2]    
    number = phone_number
    client = TelegramClient('session/' + phone_number, api_id, api_hash)    
    client.connect()    
    if not client.is_user_authorized():    
        try:    
            client.send_code_request(phone_number)    
            print(f'\n{pakuning} {kuning}Check Your Account {hijau}{phone_number}{kuning} For Code....!!! ')    
            try:    
                ans = func_timeout(60, lambda: int(input(f'{abu2}[{kuning}?{abu2}] {hijau}Enter Your Code : ')))    
                me = client.sign_in(phone_number, ans)    
            except FunctionTimedOut:    
                os.remove('session/' + phone_number+'.session')    
                print(f'\n{abu2}[{merah}x{abu2}] {merah}Waktu Habis...')    
                print(f'\r{pakuning} {kuning}Menghapus Session....!!!\n')    
                sys.exit()    
        except PhoneCodeInvalidError:    
            try:    
                sys.stdout.write(f'\n\r{abu2}[{merah}x{abu2}] {hijau}Wrong Code')    
                sleep(4)    
                print(f'\r{pakuning} {kuning}Check Your Account {hijau}{phone_number}{kuning} For Code....!!! ')    
                try:    
                    ans = func_timeout(60, lambda: int(input(f'{abu2}[{kuning}?{abu2}] {hijau}Enter Your Code : ')))    
                    me = client.sign_in(phone_number, ans)    
                except FunctionTimedOut:    
                    os.remove('session/' + phone_number+'.session')    
                    print(f'\n{abu2}[{merah}x{abu2}] {merah}Waktu Habis...')    
                    print(f'\r{pakuning} {kuning}Menghapus Session....!!!\n')    
                    sys.exit()    
            except SessionPasswordNeededError:    
                passw = input(f'{abu2}[{kuning}?{abu2}] {putih}Your 2fa Password : ')    
                client.sign_in(password=passw)
            except PhoneCodeInvalidError:    
                print(f'\n\r{abu2}[{merah}x{abu2}] {merah}Sorry ....Wrong Code')    
                sys.exit(f'{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')    
        except SessionPasswordNeededError:    
            passw = input(f'{abu2}[{kuning}?{abu2}] {putih}Your 2fa Password : ')    
            client.sign_in(password=passw)
    
    myself = client.get_me()
    pon = phone_number[3:9]
    pho = phone_number.replace(pon,'******')
    sys.stdout.write('\r                                                         \r')
    sys.stdout.write(f"\r{ffr}{biru}WELCOME         :\x1b[1;36m {myself.first_name}\n{ffr}{biru}USERNAME        :\x1b[1;36m {myself.username}\n{ffr}{biru}YOUR NUMBER     :\x1b[1;36m {pho}\n")
    try:
        if pilihan == 'doge':
            channel_entity = client.get_entity('@Dogecoin_click_bot')    
            channel_username = '@Dogecoin_click_bot'    
            currency = 'DOGE'
            dompet = dogewallet  
        if pilihan == 'ltc':    
            channel_entity = client.get_entity('@Litecoin_click_bot')    
            channel_username = '@Litecoin_click_bot'    
            currency = 'LTC'
            dompet = ltcwallet
        if pilihan == 'zec':    
            channel_entity = client.get_entity('@Zcash_click_bot')    
            channel_username = '@Zcash_click_bot'    
            currency = 'ZEC'
            dompet = zecwallet 
        if pilihan == 'bch':    
            channel_entity = client.get_entity('@BCH_clickbot')    
            channel_username = '@BCH_clickbot'    
            currency = 'BCH'
            dompet = bchwallet 
        if pilihan == 'btc':    
            channel_entity = client.get_entity('@BitcoinClick_bot')    
            channel_username = '@BitcoinClick_bot'    
            currency = 'BTC'    
            dompet = btcwallet
    except:
        pass
    print(f"{ffr}{biru}BOT             : \x1b[1;36m{channel_username}")    
    print(f"{hijau}=============================================================\n")                    
    if number in open('akun.sh', 'r').read():    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Number Already Exists In {hijau}"+'akun.sh')       
    else:    
        sh = open('akun.sh', 'a')    
        sh.write('python '+namasc+' '+phone_number+' '+pilihan+'\n')    
        sh.close()    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Account Saved In {hijau}akun.sh")    
        sleep(1)    
    if number in open('list_active.txt', 'r').read():    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Number Active Account Already Exists in {hijau}list_active.txt\n")           
    else:    
        handle = open('list_active.txt', 'a')    
        handle.write(phone_number+'\n')    
        handle.close()    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Active Account Saved In {hijau}list_active.txt\n")    
    start()
except PhoneNumberBannedError:    
    print(f'\r{abu2}[{merah}x{abu2}] \x1b[1;37m'+phone_number+f' {merah}Phone banned from Telegram')    
    sleep(1)      
    if number in open('list_banned.txt', 'r').read():    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Number Account Banned Already Exists Saved In {hijau}list_banned.txt")    
    else:    
        handle = open('list_banned.txt', 'a')    
        handle.write(phone_number+'\n')    
        handle.close()    
        sleep(1)    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Account Banned Saved In {hijau}list_banned.txt")    
    os.remove('session/' + phone_number+'.session')
    with open("akun.sh", "r") as f:     
        data = f.readlines()
        with open("akun.sh", "w") as f:     
             for line in data :     
                 if line.strip("\n") != 'python '+namasc+' '+number+' '+pilihan :    
                     f.write(line)    
                     sleep(1)
    with open("list_active.txt", "r") as f:     
        data = f.readlines()
        with open("list_active.txt", "w") as f:     
             for line in data :     
                 if line.strip("\n") != number :    
                     f.write(line)    
                     sleep(1)
    print(f'\r{pahijau} {kuning}Memperbarui data {hijau}akun.sh {kuning}dan {hijau}list_active.txt ')
    print(f'\r{pakuning} {kuning}Sukses Menghapus Session....!!! ')
    print(f"{hijau}============================================================\n")    
    sys.exit(f'{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')
except json.decoder.JSONDecodeError:
    print(f'\r{abu2}[{merah}x{abu2}] {merah}Warning Error, Please Check {kuning}{set} {merah}Again')
    print(f"{hijau}============================================================\n")
    sys.exit()
except AuthKeyUnregisteredError:
    print(f'\r{abu2}[{merah}x{abu2}] \x1b[1;37m'+phone_number+f' {merah}Session Corrupt... Please Re Enter Code')        
    if number in open('corrupt_session.txt', 'r').read():    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Number Already Exists {hijau}corrupt_session.txt")     
    else:    
        handle = open('corrupt_session.txt', 'a')    
        handle.write(phone_number+'\n')    
        handle.close()    
        sleep(1)    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Number Session Corrupt Saved In {hijau}corrupt_session.txt")    
    with open("akun.sh", "r") as f:     
        data = f.readlines()    
        with open("akun.sh", "w") as f:     
             for line in data :     
                 if line.strip("\n") != 'python '+namasc+' '+number+' '+pilihan :    
                     f.write(line)    
                     sleep(1)    
    with open("list_active.txt", "r") as f:     
        data = f.readlines()    
        with open("list_active.txt", "w") as f:     
             for line in data :     
                 if line.strip("\n") != number :    
                     f.write(line)    
                     sleep(1)    
    os.remove('session/' + phone_number+'.session')    
    print(f'\r{pakuning} {kuning}Sukses Menghapus Session....!!! ')    
    print(f"{hijau}============================================================\n")    
    sys.exit(f'\r{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')
except AuthKeyDuplicatedError:    
    print(f'\r{abu2}[{merah}x{abu2}] \x1b[1;37m'+phone_number+f' {merah}Session Corrupt... Please Re Enter Code')        
    if number in open('corrupt_session.txt', 'r').read():    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Number Already Exists {hijau}corrupt_session.txt")     
    else:    
        handle = open('corrupt_session.txt', 'a')    
        handle.write(phone_number+'\n')    
        handle.close()    
        sleep(1)    
        print(f"\r{abu2}[{kuning}+{abu2}] {kuning}Number Session Corrupt Saved In {hijau}corrupt_session.txt")    
    with open("akun.sh", "r") as f:     
        data = f.readlines()    
        with open("akun.sh", "w") as f:     
             for line in data :     
                 if line.strip("\n") != 'python '+namasc+' '+number+' '+pilihan :    
                     f.write(line)    
                     sleep(1)    
    with open("list_active.txt", "r") as f:     
        data = f.readlines()    
        with open("list_active.txt", "w") as f:     
             for line in data :     
                 if line.strip("\n") != number :    
                     f.write(line)    
                     sleep(1)    
    os.remove('session/' + phone_number+'.session')    
    print(f'\r{pakuning} {kuning}Sukses Menghapus Session....!!! ')    
    print(f"{hijau}============================================================\n")    
    sys.exit(f'\r{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')
except OperationalError:    
    print(f'\r{abu2}[{merah}x{abu2}] {merah}'+phone_number+' Database Loked.. !!!')    
    print(f'\r{abu2}[{hijau}+{abu2}] {hijau}Exit termux and run again')    
    print(f'\r{abu2}[{hijau}+{abu2}] {hijau}do not use scripts for the same account in the same folder')    
    os.remove('session/' + phone_number+'.session-journal')    
    sys.exit(f'\r{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')
    
except UserDeactivatedBanError:
    print(f'\n\r{abu2}[{merah}x{abu2}] {merah}Security Warning Banned, Please Not Run Script For This Account')
    print(f"{hijau}============================================================\n")
    sys.exit(f'{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')
except errors.FloodWaitError as e:    
    try:    
        sys.stdout.write(f"\r{abu2}[{kuning}!{abu2}] {kuning}your account must sleep {e.seconds} seconds\n")    
    finally:    
        e = None    
        del e
except KeyboardInterrupt:
    print(f'\n\n\r{abu2}[{merah}x{abu2}] {merah}Exit.....!!! \n')
    sleep(1)
    exit()
finally:    
    client.disconnect()
